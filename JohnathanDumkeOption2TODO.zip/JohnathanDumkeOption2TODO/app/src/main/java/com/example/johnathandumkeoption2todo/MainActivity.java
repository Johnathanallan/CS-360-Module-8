package com.example.johnathandumkeoption2todo;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

// MainActivity class with all fields and methods for the activity
public class MainActivity extends AppCompatActivity {
    // Initialize all fields and methods for the activity
    private EditText usernameText, passwordText;
    private Button buttonLogin, buttonCreate, buttonSmsScreen;
    private TextView loginMessage;
    private EventDbHelper db; // simple SQLite helper with users + events tables

    // onCreate method with all fields and methods for the activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);
        db = new EventDbHelper(this);

        // Initialize all fields and methods for the activity
        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);
        buttonLogin  = findViewById(R.id.buttonLogin);
        buttonCreate = findViewById(R.id.buttonCreate);
        buttonSmsScreen = findViewById(R.id.buttonSmsScreen);
        loginMessage = findViewById(R.id.loginMessage);

        // Enable/disable buttons dynamically
        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                boolean ready = hasText(usernameText) && hasText(passwordText);
                buttonLogin.setEnabled(ready);
                buttonCreate.setEnabled(ready);
            }
            @Override public void afterTextChanged(Editable s) {}
        };
        usernameText.addTextChangedListener(tw);
        passwordText.addTextChangedListener(tw);

        // Login button click listener
        buttonLogin.setOnClickListener(v -> {
            String u = usernameText.getText().toString().trim();
            String p = passwordText.getText().toString().trim();
            if (db.validateUser(u, p)) {
                loginMessage.setText("Welcome back, " + u + "!");
                goEvents();
            } else {
                loginMessage.setText("Invalid username or password.");
            }
        });

        // Create button click listener with user creation logic and validation logic for the activity
        buttonCreate.setOnClickListener(v -> {
            String u = usernameText.getText().toString().trim();
            String p = passwordText.getText().toString().trim();
            if (db.userExists(u)) {
                loginMessage.setText("User already exists. Try logging in.");
                return;
            }
            boolean ok = db.addUser(u, p);
            if (ok) {
                loginMessage.setText("Account created. You’re logged in!");
                goEvents();
            } else {
                loginMessage.setText("Could not create account. Try again.");
            }
        });

        // SMS Screen button click listener with SMS screen logic for the activity
        buttonSmsScreen.setOnClickListener(v ->
                startActivity(new Intent(this, SmsActivity.class)));
    }
    // Helper method to check if an EditText has text
    private boolean hasText(EditText e) {
        return e.getText() != null && e.getText().toString().trim().length() > 0;
    }

    // Helper method to go to the EventsActivity
    private void goEvents() {
        startActivity(new Intent(this, EventsActivity.class));
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
    }
}

