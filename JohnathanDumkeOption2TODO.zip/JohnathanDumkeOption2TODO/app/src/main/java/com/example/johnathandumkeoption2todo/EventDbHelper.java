package com.example.johnathandumkeoption2todo;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.ArrayList;
import java.util.List;

// Event Item
public class EventDbHelper extends SQLiteOpenHelper {
    private static final String DB = "events.db";
    private static final int VER = 1;

    // Event Item class with constructor and getters and setters for each field
    public EventDbHelper(Context c) { super(c, DB, null, VER); }

    // SQLiteOpenHelper methods
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users(" +
                "username TEXT PRIMARY KEY," +
                "password TEXT NOT NULL)");
        db.execSQL("CREATE TABLE events(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT NOT NULL," +
                "date TEXT NOT NULL," +
                "time TEXT NOT NULL)");
    }

    // SQLiteOpenHelper methods with onCreate and onUpgrade
    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS events");
        onCreate(db);
    }

    // Users methods with userExists, addUser, and validateUser
    public boolean userExists(String u) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT 1 FROM users WHERE username=?", new String[]{u});
        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    // Users methods with userExists, addUser, and validateUser
    public boolean addUser(String u, String p) {
        if (u.isEmpty() || p.isEmpty()) return false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", u);
        cv.put("password", p);
        long r = db.insert("users", null, cv);
        return r != -1;
    }

    // Users methods with userExists, addUser, and validateUser
    public boolean validateUser(String u, String p) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT 1 FROM users WHERE username=? AND password=?",
                new String[]{u, p});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // Events
    public List<EventItem> getAllEvents() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id,title,date,time FROM events ORDER BY date,time", null);
        List<EventItem> list = new ArrayList<>();
        while (c.moveToNext()) {
            list.add(new EventItem(
                    c.getInt(0),
                    c.getString(1),
                    c.getString(2),
                    c.getString(3)
            ));
        }
        c.close();
        return list;
    }

    // Events methods with addEvent and deleteEvent
    public boolean addEvent(String title, String date, String time) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", title);
        cv.put("date",  date);
        cv.put("time",  time);
        return db.insert("events", null, cv) != -1;
    }

    // Events methods with addEvent and deleteEvent
    public void deleteEvent(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("events", "id=?", new String[]{String.valueOf(id)});
    }
}

