package com.example.johnathandumkeoption2todo;

// Event Item class with constructor and getters and setters for each field
public class EventItem {
    public final int id;
    public final String title;
    public final String date;
    public final String time;

    // Constructor for EventItem class with all fields
    public EventItem(int id, String title, String date, String time) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.time = time;
    }
}

