package com.example.johnathandumkeoption2todo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.List;
// SMS Activity class with all fields and methods for the activity
public class SmsActivity extends AppCompatActivity {
    // Initialize all fields and methods for the activity
    private static final int REQ_SMS = 101;
    private TextView smsStatus;
    private EditText phoneText;
    private Button buttonRequestPerm, buttonSendTest;
    private EventDbHelper db;
    // onCreate method with all fields and methods for the activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        // Initialize all fields and methods for the activity with the db
        db = new EventDbHelper(this);
        smsStatus = findViewById(R.id.smsStatus);
        phoneText = findViewById(R.id.phoneText);
        buttonRequestPerm = findViewById(R.id.buttonRequestPerm);
        buttonSendTest = findViewById(R.id.buttonSendTest);

        updateStatus();
        // Request SMS permission button click listener with SMS permission logic for the activity
        buttonRequestPerm.setOnClickListener(v -> requestSmsPermission());
        // Send SMS button click listener with SMS send logic for the activity
        buttonSendTest.setOnClickListener(v -> {
            if (!hasSmsPermission()) {
                Toast.makeText(this, "Permission required to send SMS.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Get phone number from EditText
            String to = phoneText.getText() == null ? "" : phoneText.getText().toString().trim();
            // Check if phone number is empty
            if (to.isEmpty()) {
                Toast.makeText(this, "Enter a phone number.", Toast.LENGTH_SHORT).show();
                return;
            }
            List<EventItem> events = db.getAllEvents();
            // Check if there are any events
            if (events.isEmpty()) {
                Toast.makeText(this, "No events to notify.", Toast.LENGTH_SHORT).show();
                return;
            }
            // Get first event and create SMS message
            EventItem first = events.get(0); // pretend "next" event
            String msg = "Reminder: " + first.title + " on " + first.date + " at " + first.time;

            // Send SMS with SMS send logic for the activity with SMS send logic for the activity
            try {
                SmsManager.getDefault().sendTextMessage(to, null, msg, null, null);
                Toast.makeText(this, "SMS sent!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    // Helper method to check if SMS permission is granted
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }
    // Helper method to request SMS permission
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
    }
    // Helper method to update SMS status
    private void updateStatus() {
        smsStatus.setText(hasSmsPermission()
                ? "SMS permission: GRANTED"
                : "SMS permission: NOT GRANTED");
    }
    // Helper method to handle permission result
    @Override
    public void onRequestPermissionsResult(int reqCode, String[] perms, int[] res) {
        super.onRequestPermissionsResult(reqCode, perms, res);
        if (reqCode == REQ_SMS) {
            updateStatus();
        }
    }
}
