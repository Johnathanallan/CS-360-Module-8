package com.example.johnathandumkeoption2todo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

//public class eventadapter extends RecyclerView.Adapter<eventadapter.eventviewholder
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.VH> {

    interface OnDeleteClick { void onDelete(EventItem item); }

    //private final OnDeleteClick listener;
    private final OnDeleteClick listener;
    //private final List<EventItem> data = new ArrayList<>();
    private final List<EventItem> data = new ArrayList<>();

    //public EventAdapter(List<EventItem> initial, OnDeleteClick l) {
    public EventAdapter(List<EventItem> initial, OnDeleteClick l) {
        if (initial != null) data.addAll(initial);
        this.listener = l;
    }

    //add event
    public void update(List<EventItem> items) {
        data.clear();
        if (items != null) data.addAll(items);
        notifyDataSetChanged();
    }

    //delete event
    static class VH extends RecyclerView.ViewHolder {
        TextView title, date, time;
        Button delete;
        VH(@NonNull View v) {
            super(v);
            title = v.findViewById(R.id.rowTitle);
            date  = v.findViewById(R.id.rowDate);
            time  = v.findViewById(R.id.rowTime);
            delete= v.findViewById(R.id.buttonDelete);
        }
    }

    //create event
    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_event, parent, false);
        return new VH(v);
    }


    //bind event
    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        EventItem it = data.get(pos);
        h.title.setText(it.title);
        h.date.setText(it.date);
        h.time.setText(it.time);
        h.delete.setOnClickListener(v -> listener.onDelete(it));
    }

    //get event count
    @Override
    public int getItemCount() { return data.size(); }
}

