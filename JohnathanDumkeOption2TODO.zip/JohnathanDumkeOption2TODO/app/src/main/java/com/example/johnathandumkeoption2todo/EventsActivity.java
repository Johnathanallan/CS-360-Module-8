package com.example.johnathandumkeoption2todo;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

// Events Activity class with all fields and methods for the activity
public class EventsActivity extends AppCompatActivity implements EventAdapter.OnDeleteClick {
    private RecyclerView recycler;
    private EventAdapter adapter;
    private EventDbHelper db;
    private EditText editTitle, editDate, editTime;
    private Button buttonAdd;

    // onCreate method with all fields and methods for the activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        db = new EventDbHelper(this);

        recycler = findViewById(R.id.recyclerEvents);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventAdapter(db.getAllEvents(), this);
        recycler.setAdapter(adapter);

        editTitle = findViewById(R.id.editTitle);
        editDate  = findViewById(R.id.editDate);
        editTime  = findViewById(R.id.editTime);
        buttonAdd = findViewById(R.id.buttonAdd);

        // Make Date/Time fields click-only (no keyboard)
        editDate.setInputType(InputType.TYPE_NULL);
        editDate.setKeyListener(null);
        editTime.setInputType(InputType.TYPE_NULL);
        editTime.setKeyListener(null);

        editDate.setOnClickListener(v -> showDatePicker());
        editDate.setOnFocusChangeListener((v, hasFocus) -> { if (hasFocus) showDatePicker(); });

        editTime.setOnClickListener(v -> showTimePicker());
        editTime.setOnFocusChangeListener((v, hasFocus) -> { if (hasFocus) showTimePicker(); });

        buttonAdd.setOnClickListener(v -> {
            String title = editTitle.getText().toString().trim();
            String date  = editDate.getText().toString().trim();
            String time  = editTime.getText().toString().trim();
            if (TextUtils.isEmpty(title) || TextUtils.isEmpty(date) || TextUtils.isEmpty(time)) {
                return; // could show a Toast if you want feedback
            }
            db.addEvent(title, date, time);
            refresh();
            editTitle.setText("");
            editDate.setText("");
            editTime.setText("");
        });
    }

    // refresh method with all fields and methods for the activity
    private void refresh() {
        List<EventItem> items = db.getAllEvents();
        adapter.update(items);
    }

    // onDelete method with all fields and methods for the activity
    @Override
    public void onDelete(EventItem item) {
        db.deleteEvent(item.id);
        refresh();
    }

    // ----- Date/Time picker helpers -----

    // showDatePicker method with all fields and methods for the activity
    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        DatePickerDialog dlg = new DatePickerDialog(
                this,
                (view, year, month, day) -> {
                    String val = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day);
                    editDate.setText(val);
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        );
        dlg.show();
    }

    // showTimePicker method with all fields and methods for the activity
    private void showTimePicker() {
        Calendar c = Calendar.getInstance();
        TimePickerDialog dlg = new TimePickerDialog(
                this,
                (view, hour, minute) -> {
                    String val = String.format(Locale.US, "%02d:%02d", hour, minute);
                    editTime.setText(val);
                },
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE),
                true // 24-hour mode; set to false for 12-hour
        );
        dlg.show();
    }
}
