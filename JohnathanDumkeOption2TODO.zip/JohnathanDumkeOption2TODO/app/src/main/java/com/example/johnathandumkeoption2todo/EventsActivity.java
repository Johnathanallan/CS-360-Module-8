package com.example.johnathandumkeoption2todo;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;


// Events Activity class with all fields and methods for the activity
public class EventsActivity extends AppCompatActivity
        implements EventAdapter.OnDeleteClick, EventAdapter.OnEditClick {

    private RecyclerView recycler;
    private EventAdapter adapter;
    private EventDbHelper db;
    private EditText editTitle, editDate, editTime;
    private Button buttonAdd;

    // onCreate method with all fields and methods for the activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        db = new EventDbHelper(this);

        recycler = findViewById(R.id.recyclerEvents);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventAdapter(db.getAllEvents(), this, this);
        recycler.setAdapter(adapter);

        editTitle = findViewById(R.id.editTitle);
        editDate  = findViewById(R.id.editDate);
        editTime  = findViewById(R.id.editTime);
        buttonAdd = findViewById(R.id.buttonAdd);

        // Make Date/Time fields click-only (no keyboard)
        editDate.setInputType(InputType.TYPE_NULL);
        editDate.setKeyListener(null);
        editTime.setInputType(InputType.TYPE_NULL);
        editTime.setKeyListener(null);

        editDate.setOnClickListener(v -> showDatePicker());
        editDate.setOnFocusChangeListener((v, hasFocus) -> { if (hasFocus) showDatePicker(); });

        editTime.setOnClickListener(v -> showTimePicker());
        editTime.setOnFocusChangeListener((v, hasFocus) -> { if (hasFocus) showTimePicker(); });

        buttonAdd.setOnClickListener(v -> {
            String title = editTitle.getText().toString().trim();
            String date  = editDate.getText().toString().trim();
            String time  = editTime.getText().toString().trim();
            if (TextUtils.isEmpty(title) || TextUtils.isEmpty(date) || TextUtils.isEmpty(time)) {
                return; // could show a Toast if you want feedback
            }
            db.addEvent(title, date, time);
            refresh();
            editTitle.setText("");
            editDate.setText("");
            editTime.setText("");
        });
    }

    // refresh method with all fields and methods for the activity
    private void refresh() {
        List<EventItem> items = db.getAllEvents();
        adapter.update(items);
    }



    // onDelete method with all fields and methods for the activity
    @Override
    public void onDelete(EventItem item) {
        db.deleteEvent(item.id);
        refresh();
    }

    @Override
    public void onEdit(EventItem item) {
        showEditDialog(item);
    }

    // show a dialog to edit an event
    private void showEditDialog(EventItem item) {
        // Build a simple form in code
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        form.setPadding(pad, pad, pad, pad);

        // Edit fields
        EditText titleEt = new EditText(this);
        titleEt.setHint("Title");
        titleEt.setText(item.title);
        form.addView(titleEt);

        // Date and time fields
        EditText dateEt = new EditText(this);
        dateEt.setHint("YYYY-MM-DD");
        dateEt.setInputType(InputType.TYPE_NULL); // picker, no keyboard
        dateEt.setFocusable(false);
        dateEt.setText(item.date);
        dateEt.setOnClickListener(v -> showDatePickerInto(dateEt)); // NEW helper below
        form.addView(dateEt);

        // time picker
        EditText timeEt = new EditText(this);
        timeEt.setHint("HH:MM");
        timeEt.setInputType(InputType.TYPE_NULL); // picker, no keyboard
        timeEt.setFocusable(false);
        timeEt.setText(item.time);
        timeEt.setOnClickListener(v -> showTimePickerInto(timeEt)); // NEW helper below
        form.addView(timeEt);

        // Show the dialog
        new AlertDialog.Builder(this)
                .setTitle("Edit Event")
                .setView(form)
                .setPositiveButton("Save", (d, w) -> {
                    String nt  = titleEt.getText().toString().trim();
                    String nd  = dateEt.getText().toString().trim();
                    String ntm = timeEt.getText().toString().trim();
                    if (nt.isEmpty() || nd.isEmpty() || ntm.isEmpty()) {
                        Toast.makeText(this, "All fields are required.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    boolean ok = db.updateEvent(item.id, nt, nd, ntm);
                    if (ok) {
                        refresh();
                        Toast.makeText(this, "Event updated", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Date picker that writes into a specific EditText  */
    private void showDatePickerInto(EditText target) {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(
                this,
                (view, year, month, day) -> {
                    String val = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day);
                    target.setText(val);
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    /** Time picker that writes into a specific EditText */
    private void showTimePickerInto(EditText target) {
        Calendar c = Calendar.getInstance();
        new TimePickerDialog(
                this,
                (view, hour, minute) ->
                        target.setText(String.format(Locale.US, "%02d:%02d", hour, minute)),
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE),
                true
        ).show();
    }


    // ----- Date/Time picker helpers -----

    // showDatePicker method with all fields and methods for the activity
    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        DatePickerDialog dlg = new DatePickerDialog(
                this,
                (view, year, month, day) -> {
                    String val = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day);
                    editDate.setText(val);
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        );
        dlg.show();
    }

    // showTimePicker method with all fields and methods for the activity
    private void showTimePicker() {
        Calendar c = Calendar.getInstance();
        TimePickerDialog dlg = new TimePickerDialog(
                this,
                (view, hour, minute) -> {
                    String val = String.format(Locale.US, "%02d:%02d", hour, minute);
                    editTime.setText(val);
                },
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE),
                true // 24-hour mode; set to false for 12-hour
        );
        dlg.show();
    }
}
