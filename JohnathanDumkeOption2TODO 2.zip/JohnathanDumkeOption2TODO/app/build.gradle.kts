plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.johnathandumkeoption2todo"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.johnathandumkeoption2todo"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    // Needed for java.time on API < 26
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
        isCoreLibraryDesugaringEnabled = true
    }
}

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)

    // --- WorkManager (you already added this; keeping current latest) ---
    implementation("androidx.work:work-runtime:2.11.0")

    // --- Lifecycle for ViewModel + LiveData used in EventsViewModel/Activity ---
    implementation("androidx.lifecycle:lifecycle-viewmodel:2.8.6")
    implementation("androidx.lifecycle:lifecycle-livedata:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime:2.8.6")

    // --- java.time desugaring for API 24–25 (since we parse dates/times) ---
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.2")

    // Tests
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}
