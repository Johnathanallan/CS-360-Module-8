package com.example.johnathandumkeoption2todo.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.johnathandumkeoption2todo.data.EventDbHelper;
import com.example.johnathandumkeoption2todo.domain.EventItem;
import com.example.johnathandumkeoption2todo.R;
import com.example.johnathandumkeoption2todo.util.ValidationUtils;

import java.util.List;

//smsActivity will show sms permission and send a test sms

//this file will show sms permission and send a test sms


public class SmsActivity extends AppCompatActivity {
    private static final int REQ_SMS = 101;
    private TextView smsStatus;
    private EditText phoneText;
    private EventDbHelper db;

    //onCreate will bundle the savedInstanceState and set the content view to the activity_sms.xml file

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        db = new EventDbHelper(this);
        smsStatus = findViewById(R.id.smsStatus);
        phoneText = findViewById(R.id.phoneText);
        Button buttonRequestPerm = findViewById(R.id.buttonRequestPerm);
        Button buttonSendTest = findViewById(R.id.buttonSendTest);

        updateStatus();

        buttonRequestPerm.setOnClickListener(v -> requestSmsPermission());

        //buttonSendTest will send a test sms
        //it will be used to send a test sms

        buttonSendTest.setOnClickListener(v -> {
            String to = phoneText.getText() == null ? "" : phoneText.getText().toString().trim();
            // Validate
            if (!ValidationUtils.isLikelyPhone(to)) {
                Toast.makeText(this, "Enter a valid phone number.", Toast.LENGTH_SHORT).show();
                return;
            }
            // Check for events
            List<EventItem> events = db.getAllEvents();
            if (events.isEmpty()) {
                Toast.makeText(this, "No events to notify.", Toast.LENGTH_SHORT).show();
                return;
            }
            EventItem first = events.get(0);
            String msg = "Reminder: " + first.title + " on " + first.date + " at " + first.time;

            // SAFER: send SMS with SEND_SMS permission
            if (hasSmsPermission()) {
                try {
                    SmsManager.getDefault().sendTextMessage(to, null, msg, null, null);
                    Toast.makeText(this, "SMS sent!", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                // SAFER FALLBACK: open default SMS app prefilled (no SEND_SMS permission needed)
                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("smsto:" + Uri.encode(to)));
                intent.putExtra("sms_body", msg);
                //TRY WILL TRY TO SEND THE SMS
                //IF IT FAILS IT WILL SHOW A TOAST MESSAGE
                //IF IT WORKS IT WILL SHOW A TOAST MESSAGE
                try {
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(this, "No SMS app available.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    //hasSmsPermission will check if the user has sms permission

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    //requestSmsPermission will request sms permission

    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
    }

    //updateStatus will update the status of the sms permission
    private void updateStatus() {
        smsStatus.setText(hasSmsPermission()
                ? "SMS permission: GRANTED"
                : "SMS permission: NOT GRANTED (fallback to SMS app)");
    }

    //onRequestPermissionsResult will handle the result of the permission request

    @Override
    public void onRequestPermissionsResult(int reqCode, String[] perms, int[] res) {
        super.onRequestPermissionsResult(reqCode, perms, res);
        if (reqCode == REQ_SMS) {
            updateStatus();
        }
    }
}
