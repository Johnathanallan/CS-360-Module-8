package com.example.johnathandumkeoption2todo.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.johnathandumkeoption2todo.data.EventDbHelper;
import com.example.johnathandumkeoption2todo.util.NotificationHelper;
import com.example.johnathandumkeoption2todo.R;

//MainActivity will be used to login and create accounts
//this file will be used to login and create accounts

public class MainActivity extends AppCompatActivity {
    // Android 13+ requires POST_NOTIFICATIONS for NotificationManager.notify()
    private static final int REQ_POST_NOTIFICATIONS = 102;

    private EditText usernameText, passwordText;
    private Button buttonLogin, buttonCreate, buttonSmsScreen;
    private TextView loginMessage;
    private EventDbHelper db; // simple SQLite helper with users + events tables

    //onCreate will bundle the savedInstanceState and set the content view to the activity_main.xml file

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);
        db = new EventDbHelper(this);

        NotificationHelper.ensureChannel(getApplicationContext());


        //Ask for notification permission on Android 13+ so Workers can post notifications
        requestPostNotificationsIfNeeded();

        usernameText   = findViewById(R.id.usernameText);
        passwordText   = findViewById(R.id.passwordText);
        buttonLogin    = findViewById(R.id.buttonLogin);
        buttonCreate   = findViewById(R.id.buttonCreate);
        buttonSmsScreen= findViewById(R.id.buttonSmsScreen);
        loginMessage   = findViewById(R.id.loginMessage);

        //setOnClickListener will set the onClickListener for the buttonLogin and buttonCreate fields

        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                boolean ready = hasText(usernameText) && hasText(passwordText);
                buttonLogin.setEnabled(ready);
                buttonCreate.setEnabled(ready);
            }
            @Override public void afterTextChanged(Editable s) {}
        };
        usernameText.addTextChangedListener(tw);
        passwordText.addTextChangedListener(tw);

        //setOnClickListener will set the onClickListener for the buttonLogin and buttonCreate fields

        buttonLogin.setOnClickListener(v -> {
            String u = usernameText.getText().toString().trim();
            String p = passwordText.getText().toString().trim();
            if (db.validateUser(u, p)) {
                loginMessage.setText("Welcome back, " + u + "!");
                goEvents();
            } else {
                loginMessage.setText("Invalid username or password.");
            }
        });

        //setOnClickListener will set the onClickListener for the buttonLogin and buttonCreate fields

        buttonCreate.setOnClickListener(v -> {
            String u = usernameText.getText().toString().trim();
            String p = passwordText.getText().toString().trim();
            if (db.userExists(u)) {
                loginMessage.setText("User already exists. Try logging in.");
                return;
            }
            boolean ok = db.addUser(u, p);
            if (ok) {
                loginMessage.setText("Account created. You’re logged in!");
                goEvents();
            } else {
                loginMessage.setText("Could not create account. Try again.");
            }
        });

        buttonSmsScreen.setOnClickListener(v ->
                startActivity(new Intent(this, SmsActivity.class)));
    }

    /** Android 13+ requires POST_NOTIFICATIONS for NotificationManager.notify(...) */
    private void requestPostNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            int granted = ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS);
            if (granted != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{ Manifest.permission.POST_NOTIFICATIONS },
                        REQ_POST_NOTIFICATIONS
                );
            }
        }
    }

    //onRequestPermissionsResult will handle the result of the permission request

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_POST_NOTIFICATIONS && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            Toast.makeText(
                    this,
                    granted ? "Notifications enabled." : "Notifications disabled — reminders will still save but won’t alert.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    //hasText will check if the given EditText has text

    private boolean hasText(EditText e) {
        return e.getText() != null && e.getText().toString().trim().length() > 0;
    }

    //goEvents will start the EventsActivity


    private void goEvents() {
        startActivity(new Intent(this, EventsActivity.class));
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
    }
}
