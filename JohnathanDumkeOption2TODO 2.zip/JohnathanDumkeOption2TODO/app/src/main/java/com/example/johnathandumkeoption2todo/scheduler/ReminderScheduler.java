package com.example.johnathandumkeoption2todo.scheduler;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import com.example.johnathandumkeoption2todo.worker.ReminderWorker;

import java.util.concurrent.TimeUnit;

//class will reminderSchedule at an absolute wall-clock time (epochMillis).

public final class ReminderScheduler {

    private ReminderScheduler() {}

    /** Schedule a one-shot reminder at an absolute wall-clock time (epochMillis). */
    public static void scheduleAt(
            @NonNull Context ctx,
            int eventId,
            @NonNull String title,
            @NonNull String date,
            @NonNull String time,            // display string, not parsed
            @NonNull String details,         // can be empty
            long triggerAtMillis,
            long nowMillis
    ) {
        long delayMs = Math.max(0L, triggerAtMillis - nowMillis);

        // pass data to worker
        Data input = new Data.Builder()
                .putString("title", title)
                .putString("date",  date)
                .putString("time",  time)
                .putString("details", details)
                .build();

        // schedule reminder
        OneTimeWorkRequest req =
                new OneTimeWorkRequest.Builder(ReminderWorker.class)
                        .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
                        .setInputData(input)
                        .addTag("event-" + eventId)
                        .build();

        // enqueue unique work
        String uniqueName = "reminder-" + eventId;
        WorkManager.getInstance(ctx)
                .enqueueUniqueWork(uniqueName, ExistingWorkPolicy.REPLACE, req);
    }

    /** Cancel any scheduled reminder for this event id. */
    public static void cancel(@NonNull Context ctx, int eventId) {
        String uniqueName = "reminder-" + eventId;
        WorkManager.getInstance(ctx).cancelUniqueWork(uniqueName);
    }
}
