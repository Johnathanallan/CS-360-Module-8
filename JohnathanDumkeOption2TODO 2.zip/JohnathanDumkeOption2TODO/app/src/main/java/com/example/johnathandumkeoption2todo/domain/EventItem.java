package com.example.johnathandumkeoption2todo.domain;

//eventItem will be used to store the data for each event

public class EventItem {
    public final int    id;
    public final String title;
    public final String date;
    public final String time;
    public final String notes; // NEW

    // NEW ctor used when we don't have notes
    public EventItem(int id, String title, String date, String time) {
        this(id, title, date, time, ""); // default empty notes
    }

    // NEW ctor used when we load notes from DB
    public EventItem(int id, String title, String date, String time, String notes) {
        this.id    = id;
        this.title = title;
        this.date  = date;
        this.time  = time;
        this.notes = notes == null ? "" : notes;
    }
}
