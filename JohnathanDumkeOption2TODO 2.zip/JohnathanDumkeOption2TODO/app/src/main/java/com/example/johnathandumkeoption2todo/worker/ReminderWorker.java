package com.example.johnathandumkeoption2todo.worker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.johnathandumkeoption2todo.util.NotificationHelper;

//ReminderWorker will be used to schedule reminders for events


public class ReminderWorker extends Worker {

    private static final String TAG = "ReminderWorker";

    // Constructor is required, though you don't usually need to use it
    public ReminderWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    //doWork will be used to schedule reminders for events
    //it will be used to schedule reminders for events

    @NonNull @Override
    public Result doWork() {
        Context ctx = getApplicationContext();

        // Read inputs from WorkManager
        Data in = getInputData();
        String title   = in.getString("title");
        String date    = in.getString("date");
        String time    = in.getString("time");
        String details = in.getString("details"); // optional

        // 1) Ensure channel exists (safe to call repeatedly)
        NotificationHelper.ensureChannel(ctx);

        // 2) On Android 13+ you must have POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            int perm = ContextCompat.checkSelfPermission(
                    ctx, android.Manifest.permission.POST_NOTIFICATIONS);
            if (perm != PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "POST_NOTIFICATIONS not granted; skipping notification.");
                return Result.success(); // can't request from a background worker
            }
        }

        // 3) If the user globally disabled notifications for this app, skip
        NotificationManagerCompat nm = NotificationManagerCompat.from(ctx);
        if (!nm.areNotificationsEnabled()) {
            Log.w(TAG, "Notifications disabled by user; skipping notification.");
            return Result.success();
        }

        // 4) Build the notification
        String content = buildContentLine(date, time, details);
        String safeTitle = (title != null && !title.isEmpty()) ? title : "Event Reminder";

        NotificationCompat.Builder nb =
                new NotificationCompat.Builder(ctx, NotificationHelper.CHANNEL_ID)
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle(safeTitle)
                        .setContentText(content)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(content))
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setCategory(NotificationCompat.CATEGORY_REMINDER)
                        .setAutoCancel(true);

        // 5) Post it safely (guarded; permission already checked)
        int notificationId = (int) (System.currentTimeMillis() & 0x7FFFFFFF);
        try {
            postNotification(nm, notificationId, nb);
        } catch (SecurityException se) {
            // If permission is revoked between check and post, just swallow safely
            Log.w(TAG, "SecurityException when notifying; likely permission revoked at runtime.", se);
        }

        return Result.success();
    }

    //method will post a notification
    //it will be used to post a notification

    @SuppressLint("MissingPermission") // We gate by permission + areNotificationsEnabled() above
    private void postNotification(NotificationManagerCompat nm, int id, NotificationCompat.Builder nb) {
        nm.notify(id, nb.build());
    }

    //method will build the content line
    //it will be used to build the content line

    private String buildContentLine(String date, String time, String details) {
        String when = "";
        if (date != null && !date.isEmpty()) {
            when = date;
            if (time != null && !time.isEmpty()) {
                when += " " + time;
            }
        } else if (time != null && !time.isEmpty()) {
            when = time;
        }
        String base = when.isEmpty() ? "You have a scheduled event." : ("Scheduled: " + when);
        if (details != null && !details.trim().isEmpty()) {
            return base + "\n" + details.trim();
        }
        return base;
    }
}
