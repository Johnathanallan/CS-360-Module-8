package com.example.johnathandumkeoption2todo.ui;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.johnathandumkeoption2todo.data.EventDbHelper;
import com.example.johnathandumkeoption2todo.domain.EventItem;
import com.example.johnathandumkeoption2todo.R;
import com.example.johnathandumkeoption2todo.scheduler.ReminderScheduler;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Displays and manages Events (list, add, edit, delete).
 * Now also schedules/cancels WorkManager reminders via ReminderScheduler.
 */
public class EventsActivity extends AppCompatActivity
        implements EventAdapter.OnDeleteClick, EventAdapter.OnEditClick {

    private RecyclerView recycler;
    private EventAdapter adapter;
    private EventDbHelper db;
    private EditText editTitle, editDate, editTime;
    private Button buttonAdd;

    //Oncreate will bundle the savedInstanceState and set the content view to the activity_events.xml file
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        db = new EventDbHelper(this);

        recycler = findViewById(R.id.recyclerEvents);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventAdapter(db.getAllEvents(), this, this);
        recycler.setAdapter(adapter);

        editTitle = findViewById(R.id.editTitle);
        editDate  = findViewById(R.id.editDate);
        editTime  = findViewById(R.id.editTime);
        buttonAdd = findViewById(R.id.buttonAdd);

        // Make date/time fields picker-only
        editDate.setInputType(InputType.TYPE_NULL);
        editDate.setKeyListener(null);
        editTime.setInputType(InputType.TYPE_NULL);
        editTime.setKeyListener(null);

        editDate.setOnClickListener(v -> showDatePicker());
        editDate.setOnFocusChangeListener((v, hasFocus) -> { if (hasFocus) showDatePicker(); });

        editTime.setOnClickListener(v -> showTimePicker());
        editTime.setOnFocusChangeListener((v, hasFocus) -> { if (hasFocus) showTimePicker(); });

        //buttonAdd will add a new event to the database
        //it will also schedule a reminder for the event
        buttonAdd.setOnClickListener(v -> {
            String title = safeText(editTitle);
            String date  = safeText(editDate);
            String time  = safeText(editTime);
            String notes = ""; // no notes field on the add row; default empty

            // Validate
            if (TextUtils.isEmpty(title)) {
                Toast.makeText(this, "Title is required.", Toast.LENGTH_SHORT).show();
                return;
            }
            // Validate date
            if (!isIsoDate(date)) {
                Toast.makeText(this, "Use date format YYYY-MM-DD.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate time
            if (TextUtils.isEmpty(time)) {
                Toast.makeText(this, "Time is required.", Toast.LENGTH_SHORT).show();
                return;
            }

            //long when = combineToEpochMillis(date, time);
            //if will check if the date and time are valid
            //if not it will show a toast message

            Long when = combineToEpochMillis(date, time);
            if (when == null) {
                Toast.makeText(this, "Invalid date/time.", Toast.LENGTH_SHORT).show();
                return;
            }

            //new will check if the date and time are in the future
            //if not it will show a toast message

            long now = System.currentTimeMillis();
            if (when < now + 60_000) {
                Toast.makeText(this, "Please pick 1 minute in the future.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Insert and schedule
            int newId = db.addEvent(title, date, time, notes);
            if (newId <= 0) {
                Toast.makeText(this, "Save failed.", Toast.LENGTH_SHORT).show();
                return;
            }

            // schedule the reminder for this event id
            //ReminderScheduler.scheduleAt
            ReminderScheduler.scheduleAt(
                    this,
                    newId,
                    title,
                    date,
                    time,
                    notes,
                    /* triggerAtMillis = */ when,
                    /* nowMillis = */ now
            );

            refresh();
            editTitle.setText("");
            editDate.setText("");
            editTime.setText("");
            Toast.makeText(this, "Event saved & reminder scheduled.", Toast.LENGTH_SHORT).show();
        });
    }

    //refresh will update the recycler view with the new data
    //it will also update the adapter with the new data

    private void refresh() {
        List<EventItem> items = db.getAllEvents();
        adapter.update(items);
    }

    //onDelete will delete an event from the database
    //it will also cancel the reminder for the event

    @Override
    public void onDelete(EventItem item) {
        db.deleteEvent(item.id);
        // cancel any scheduled reminder for this event
        ReminderScheduler.cancel(this, item.id);
        refresh();
        Toast.makeText(this, "Event deleted.", Toast.LENGTH_SHORT).show();
    }

    //onEdit will edit an event in the database
    //it will also reschedule the reminder for the event

    @Override
    public void onEdit(EventItem item) {
        showEditDialog(item);
    }

    //showEditDialog will show a dialog to edit an event
    //it will also reschedule the reminder for the event

    private void showEditDialog(final EventItem item) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        form.setPadding(pad, pad, pad, pad);

        // Title
        final EditText titleEt = new EditText(this);
        titleEt.setHint("Title");
        titleEt.setText(item.title);
        form.addView(titleEt);

        // Date
        final EditText dateEt = new EditText(this);
        dateEt.setHint("YYYY-MM-DD");
        dateEt.setInputType(InputType.TYPE_NULL);
        dateEt.setFocusable(false);
        dateEt.setText(item.date);
        dateEt.setOnClickListener(v -> showDatePickerInto(dateEt));
        form.addView(dateEt);

        // Time
        final EditText timeEt = new EditText(this);
        timeEt.setHint("HH:MM  or  h:mm AM/PM");
        timeEt.setInputType(InputType.TYPE_NULL);
        timeEt.setFocusable(false);
        timeEt.setText(item.time);
        timeEt.setOnClickListener(v -> showTimePickerInto(timeEt));
        form.addView(timeEt);

        // Notes
        final EditText notesEt = new EditText(this);
        notesEt.setHint("Notes (optional)");
        notesEt.setText(item.notes == null ? "" : item.notes);
        form.addView(notesEt);

        // Show dialog to edit
        new AlertDialog.Builder(this)
                .setTitle("Edit Event")
                .setView(form)
                .setPositiveButton("Save", (d, w) -> {
                    String nt  = titleEt.getText().toString().trim();
                    String nd  = dateEt.getText().toString().trim();
                    String ntm = timeEt.getText().toString().trim();
                    String nn  = notesEt.getText().toString().trim();

                    // Validate
                    if (nt.isEmpty() || nd.isEmpty() || ntm.isEmpty()) {
                        Toast.makeText(this, "Title, Date, and Time are required.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    // Validate date
                    if (!isIsoDate(nd)) {
                        Toast.makeText(this, "Use date format YYYY-MM-DD.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    // Validate time

                    Long when2 = combineToEpochMillis(nd, ntm);
                    if (when2 == null) {
                        Toast.makeText(this, "Invalid date/time.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    //long now = System.currentTimeMillis();
                    //if will check if the date and time are valid
                    //if not it will show a toast message

                    long now = System.currentTimeMillis();
                    if (when2 < now + 60_000) {
                        Toast.makeText(this, "Please pick 1 minute in the future.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Update and reschedule
                    //db.updateEvent will update the event in the database
                    boolean ok = db.updateEvent(item.id, nt, nd, ntm, nn); // 5-arg update
                    if (ok) {
                        // reschedule the reminder for this event id
                        ReminderScheduler.scheduleAt(
                                this,
                                item.id,
                                nt, nd, ntm, nn,
                                /* triggerAtMillis = */ when2,
                                /* nowMillis = */ now
                        );
                        refresh();
                        Toast.makeText(this, "Event updated & reminder rescheduled.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    //showDatePicker will show a date picker dialog
    //it will also set the date field to the selected date

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        DatePickerDialog dlg = new DatePickerDialog(
                this,
                (view, year, month, day) -> {
                    String val = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day);
                    editDate.setText(val);
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        );
        dlg.show();
    }

    //showTimePicker will show a time picker dialog
    //it will also set the time field to the selected time

    private void showTimePicker() {
        Calendar c = Calendar.getInstance();
        boolean use24h = android.text.format.DateFormat.is24HourFormat(this);
        TimePickerDialog dlg = new TimePickerDialog(
                this,
                (view, hour, minute) -> setTimeField(editTime, hour, minute, use24h),
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE),
                use24h
        );
        dlg.show();
    }

    //show date picker into will show a date picker dialog
    //it will also set the date field to the selected date

    private void showDatePickerInto(EditText target) {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(
                this,
                (view, year, month, day) -> {
                    String val = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day);
                    target.setText(val);
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    //show time picker into will show a time picker dialog
    //it will also set the time field to the selected time

    private void showTimePickerInto(EditText target) {
        boolean use24h = android.text.format.DateFormat.is24HourFormat(this);
        int[] hm = parseUserTime(target.getText() == null ? null : target.getText().toString());
        new TimePickerDialog(
                this,
                (view, hour, minute) -> setTimeField(target, hour, minute, use24h),
                hm[0],
                hm[1],
                use24h
        ).show();
    }

    //setTimeField will set the time field to the selected time

    private void setTimeField(EditText target, int hour, int minute, boolean use24h) {
        if (use24h) {
            target.setText(String.format(Locale.US, "%02d:%02d", hour, minute));
        } else {
            int displayHour = hour % 12;
            if (displayHour == 0) displayHour = 12;
            String suffix = (hour < 12) ? "AM" : "PM";
            target.setText(String.format(Locale.US, "%d:%02d %s", displayHour, minute, suffix));
        }
    }

    //safeText will return the text from the edit text field
    //if the edit text field is null it will return an empty string
    //if the edit text field is empty it will return an empty string
    // EXT WILL
    private static String safeText(EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    //isIsoDate will check if the date is in the format YYYY-MM-DD
    //if not it will return false
    private static boolean isIsoDate(String ymd) {
        return ymd != null && ymd.matches("\\d{4}-\\d{2}-\\d{2}");
    }

    /** Parse user time into [hour24, minute]. Supports "HH:mm", "h:mm AM/PM", or "h:mm" on 12h devices. */
    private int[] parseUserTime(String timeText) {
        Calendar now = Calendar.getInstance();
        int defH = now.get(Calendar.HOUR_OF_DAY);
        int defM = now.get(Calendar.MINUTE);

        if (timeText == null) return new int[]{defH, defM};
        String t = timeText.trim();
        if (t.isEmpty()) return new int[]{defH, defM};

        //try will check if the time is in the correct format

        try {
            // "h:mm AM/PM"
            if (t.matches("(?i)^\\s*\\d{1,2}:\\d{2}\\s*(AM|PM)\\s*$")) {
                String[] parts = t.toUpperCase(Locale.US).trim().split("\\s+");
                String[] hm = parts[0].split(":");
                int h = Integer.parseInt(hm[0]);
                int m = Integer.parseInt(hm[1]);
                boolean pm = "PM".equals(parts[1]);
                if (h == 12) {
                    h = pm ? 12 : 0;   // 12AM -> 0, 12PM -> 12
                } else if (pm) {
                    h += 12;          // 1..11 PM -> 13..23
                }
                return new int[]{clamp(h, 0, 23), clamp(m, 0, 59)};
            }
            // "HH:mm" or "h:mm" (no AM/PM)
            if (t.matches("^\\s*\\d{1,2}:\\d{2}\\s*$")) {
                String[] hm = t.trim().split(":");
                int h = Integer.parseInt(hm[0]);
                int m = Integer.parseInt(hm[1]);
                boolean deviceIs24h = android.text.format.DateFormat.is24HourFormat(this);
                if (!deviceIs24h) {
                    int ampm = now.get(Calendar.AM_PM); // 0=AM, 1=PM
                    if (ampm == Calendar.PM && h < 12) {
                        h += 12; // "1:20" during PM -> 13:20
                    } else if (ampm == Calendar.AM && h == 12) {
                        h = 0;   // "12:15" during AM -> 00:15
                    }
                }
                return new int[]{clamp(h, 0, 23), clamp(m, 0, 59)};
            }
        } catch (Exception ignore) { /* fall back */ }

        return new int[]{defH, defM};
    }

    //clamp will clamp the value to the given range
    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Combine ISO date (YYYY-MM-DD) + user time string into epoch millis (local timezone). */
    private Long combineToEpochMillis(String date, String timeText) {
        if (!isIsoDate(date) || timeText == null) return null;

        int year  = Integer.parseInt(date.substring(0, 4));
        int month = Integer.parseInt(date.substring(5, 7)) - 1; // Calendar months are 0-based
        int day   = Integer.parseInt(date.substring(8, 10));

        int[] hm = parseUserTime(timeText);

        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DAY_OF_MONTH, day);
        c.set(Calendar.HOUR_OF_DAY, hm[0]);
        c.set(Calendar.MINUTE, hm[1]);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }
}
