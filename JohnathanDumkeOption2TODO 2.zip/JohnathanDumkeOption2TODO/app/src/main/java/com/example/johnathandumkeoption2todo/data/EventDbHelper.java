package com.example.johnathandumkeoption2todo.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.johnathandumkeoption2todo.domain.EventItem;

import java.util.ArrayList;
import java.util.List;

/** SQLite helper for users and events (now with notes). */
//EventDbhelper is a class that extends SQLiteOpenHelper and is used to create and manage a
// SQLite database.

public class EventDbHelper extends SQLiteOpenHelper {

    // Database name and version constants are now static
    private static final String DB_NAME = "events.db";
    // Bump to 2 to add the notes column
    private static final int DB_VERSION = 2;

    // Constructor is now public for testing
    public EventDbHelper(Context c) {
        super(c, DB_NAME, null, DB_VERSION);
    }

    // on create is now a no-op and will create the users and events tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users(" +
                "username TEXT PRIMARY KEY," +
                "password TEXT NOT NULL)");

        db.execSQL("CREATE TABLE events(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT NOT NULL," +
                "date TEXT NOT NULL," +
                "time TEXT NOT NULL," +
                "notes TEXT DEFAULT ''" +    // NEW column
                ")");
    }

    //onUpgrade will be used to update the database if the version number changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        // Simple forward migration for v1 -> v2: add notes column if missing
        if (oldV < 2) {
            db.execSQL("ALTER TABLE events ADD COLUMN notes TEXT DEFAULT ''");
        }
    }

    // ---------- Users ----------

    //userexists will check if a user exists in the database


    public boolean userExists(String u) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT 1 FROM users WHERE username=?",
                new String[]{u});
        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    //adduser will add a user to the database

    public boolean addUser(String u, String p) {
        if (u == null || u.trim().isEmpty() || p == null || p.trim().isEmpty()) return false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", u.trim());
        cv.put("password", p);
        return db.insert("users", null, cv) != -1;
    }

    //validateuser will check if a user exists in the database and if the password is correct

    public boolean validateUser(String u, String p) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT 1 FROM users WHERE username=? AND password=?",
                new String[]{u, p});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // ---------- Events ----------




    /**
     * New overload with notes.
     */
    // Change signature to return int id (or -1 on failure)
    public int addEvent(String title, String date, String time, String notes) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", title);
        cv.put("date",  date);
        cv.put("time",  time);
        cv.put("notes", notes); // make sure your table has this column
        long rowId = db.insert("events", null, cv);
        return (int) rowId; // returns -1 on failure
    }




    /** New overload with notes. */
    public boolean updateEvent(int id, String title, String date, String time, String notes) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", title);
        cv.put("date",  date);
        cv.put("time",  time);
        if (notes != null) {
            cv.put("notes", notes);
        }
        return db.update("events", cv, "id=?", new String[]{String.valueOf(id)}) > 0;
    }

    //deleteevent will delete an event from the database

    public void deleteEvent(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("events", "id=?", new String[]{String.valueOf(id)});
    }

    /** Now selects notes and constructs EventItem(id, title, date, time, notes). */
    public List<EventItem> getAllEvents() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT id, title, date, time, COALESCE(notes,'') " +
                        "FROM events ORDER BY date, time", null);

        List<EventItem> list = new ArrayList<>();
        while (c.moveToNext()) {
            list.add(new EventItem(
                    c.getInt(0),          // id
                    c.getString(1),       // title
                    c.getString(2),       // date
                    c.getString(3),       // time
                    c.getString(4)        // notes
            ));
        }
        c.close();
        return list;
    }
}
