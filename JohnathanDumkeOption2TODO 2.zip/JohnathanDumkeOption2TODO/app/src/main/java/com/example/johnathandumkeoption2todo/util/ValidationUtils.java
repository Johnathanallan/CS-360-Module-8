package com.example.johnathandumkeoption2todo.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

//ValidationUtils will validate the date and time

//this file will validate the date and time

public final class ValidationUtils {
    private ValidationUtils() {}

    // Accepts "YYYY-MM-DD" and "HH:MM" 24h
    public static long parseDateTimeMillis(String date, String time) throws ParseException {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        return f.parse(date + " " + time).getTime();
    }

    // Accepts "YYYY-MM-DD"
    public static boolean isNonEmpty(String s) {
        return s != null && !s.trim().isEmpty();
    }

    // Accepts "YYYY-MM-DD"
    public static boolean isLikelyPhone(String s) {
        if (!isNonEmpty(s)) return false;
        String digits = s.replaceAll("\\D", "");
        return digits.length() >= 10 && digits.length() <= 15;
    }
}
