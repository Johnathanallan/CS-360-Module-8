package com.example.johnathandumkeoption2todo.util;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

//this file handles the notification channel for the app
//it will be used to create a notification channel for the app

public final class NotificationHelper {
    public static final String CHANNEL_ID = "event_reminders";
    public static final String CHANNEL_NAME = "Event Reminders";

    private NotificationHelper() {}

    //void ensureChannel will ensure that the notification channel exists

    public static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            ch.setDescription("Reminders for upcoming events");
            NotificationManager nm = ctx.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }
}
