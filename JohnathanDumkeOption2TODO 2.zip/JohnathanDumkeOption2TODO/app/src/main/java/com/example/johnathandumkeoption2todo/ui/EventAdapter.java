package com.example.johnathandumkeoption2todo.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.johnathandumkeoption2todo.domain.EventItem;
import com.example.johnathandumkeoption2todo.R;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;


//public class EventsActivity extends AppCompatActivity code will delete on click of the button
// and edit on the click of the button

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.VH> {

    interface OnDeleteClick { void onDelete(EventItem item); }
    interface OnEditClick   { void onEdit(EventItem item); }

    //private to prevent accidental use
    //data is a list of EventItem objects
    //deleteListener and editListener are the listeners for the delete and edit buttons
    private final OnDeleteClick deleteListener;
    private final OnEditClick   editListener;
    private final List<EventItem> data = new ArrayList<>();

    // 3-arg constructor (the one used in the latest EventsActivity)
    public EventAdapter(List<EventItem> initial, OnDeleteClick del, OnEditClick edit) {
        if (initial != null) data.addAll(initial);
        this.deleteListener = del;
        this.editListener   = edit;
    }

    //4-arg overload for older calling code: forwards to the 3-arg one
    public EventAdapter(Context ignored, List<EventItem> initial, OnDeleteClick del, OnEditClick edit) {
        this(initial, del, edit);
    }

    //update method to update the data in the adapter
    public void update(List<EventItem> items) {
        data.clear();
        if (items != null) data.addAll(items);
        notifyDataSetChanged();
    }

    //class to hold the views for each row in the recycler view
    static class VH extends RecyclerView.ViewHolder {
        TextView        title, date, time;
        MaterialButton  edit;
        Button          delete;

        //vh constructor to find the views in the layout
        //each row has a title, date, time, edit button, and delete button
        VH(@NonNull View v) {
            super(v);
            title  = v.findViewById(R.id.rowTitle);
            date   = v.findViewById(R.id.rowDate);
            time   = v.findViewById(R.id.rowTime);
            edit   = v.findViewById(R.id.buttonEdit);
            delete = v.findViewById(R.id.buttonDelete);
        }
    }

    //3 methods to implement the adapter
    //onCreateViewHolder is called when the recycler view needs a new view holder
    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_event, parent, false);
        return new VH(v);
    }

    //onBindViewHolder is called when the recycler view needs to bind data to a view holder
    //it sets the text of the title, date, and time fields to the corresponding values in the data list
    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        EventItem it = data.get(pos);
        h.title.setText(it.title);
        h.date.setText(it.date);
        h.time.setText(it.time);

        h.delete.setOnClickListener(v -> deleteListener.onDelete(it));
        h.edit.setOnClickListener(v -> editListener.onEdit(it));
    }

    //getItemCount returns the number of items in the data list
    //this is used by the recycler view to determine when to stop scrolling
    @Override
    public int getItemCount() { return data.size(); }
}
